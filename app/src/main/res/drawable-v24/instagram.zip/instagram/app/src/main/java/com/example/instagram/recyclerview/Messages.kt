package com.example.instagram.recyclerview


class Messages (val userPFP: Int,
                val userName: String,
                val userActivity: String)