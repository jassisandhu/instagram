package com.example.instagram.recyclerview

data class ModelStory(val sPFP: Int,
                      val sName: String)