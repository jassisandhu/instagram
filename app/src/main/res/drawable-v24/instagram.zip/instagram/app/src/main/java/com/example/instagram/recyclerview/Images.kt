package com.example.instagram.recyclerview


data class Images (val username: String,
                   val user_pfp: Int,
                   val image: Int)